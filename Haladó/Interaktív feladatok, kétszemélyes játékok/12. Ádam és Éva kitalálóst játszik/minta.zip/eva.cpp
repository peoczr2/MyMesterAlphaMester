#include <bits/stdc++.h>
#include "eva.h"

#define _MaxH  16
#define _MaxN  10001

using namespace std;

int GetN() {

}  /*GetN*/

int GetH() {

}  /*GetH*/

int Kerdes(int x) {

}  /*Kerdes*/

void Megoldas(int x) {

}  /*Megoldas*/
