#ifdef __cplusplus
extern "C" {
#endif

extern int GetN();
extern int GetH();
extern int Kerdes(int x);
extern void Megoldas(int x);

#ifdef __cplusplus
}
#endif
