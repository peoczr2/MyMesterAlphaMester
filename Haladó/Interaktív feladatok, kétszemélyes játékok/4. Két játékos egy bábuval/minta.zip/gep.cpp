#include <bits/stdc++.h>
#include "gep.h"

using namespace std;

const int maxN=1000;
int NN;
bool kezdett = false;
int pont = 0, x = 0, y = 0;
char geplepese;
int Tabla[maxN][maxN];

void message(int p, string msg) {
	cout << msg << endl;
	cout << p << endl;
	exit(0);
}

int Mezo(int i, int j) {
	if (!kezdett) {
		message(0, "Hiba, a játékot a Kezd művelettel kell kezdeni!");
	}
	if (i < 0 || i >= NN || j < 0 || j >= NN) {
		message(0, "Hiba, érvénytelen paraméter Mezo-ben.");
	}
	return Tabla[i][j];
}

void Lep(char c) {
	if (!kezdett) {
		message(0, "Hiba, a játékot a Kezd művelettel kell kezdeni!");
	}
	if (c != 'L' && c != 'J') {
		message(0, "Hiba, érvénytelen paraméter Lep-ben");
	}
	if (c == 'L') {
		if (++x == NN) {
			message(0, "Hiba, érvénytelen paraméter Lep-ben");
		}
	}else {
		if (++y == NN) {
			message(0, "Hiba, érvénytelen paraméter Lep-ben");
		}
	}
	pont += Tabla[x][y];
	if (x == NN - 1) {
		geplepese = 'J';
		++y;
	}else {
		geplepese = 'L';
		++x;
	}
	if (x == NN - 1 && y == NN - 1) {
		message(pont, "Helyes");
	}
}

char GepLep() {
	if (!kezdett) {
		message(0, "Hiba, a játékot a Kezd művelettel kell kezdeni!");
	}
	return geplepese;
}

int Kezd() {
	if (kezdett) {
		message(0, "Hiba, Kezd-et csak egyszer szabad hívni.");
	}

	kezdett = true;
	int m;
	cin >> NN >> m;
   for(int i=0;i<NN;i++)
      for(int j=0;j<NN;j++)
         Tabla[i][j]=0;
	for (int i = 0; i < m; ++i) {
		int x, y, k;
		cin >> x >> y >> k;
		Tabla[x][y] = k;
	}
	return NN;
}
