int Kezd();
int Mezo(int i, int j);
void Lep(char L);
char GepLep();
