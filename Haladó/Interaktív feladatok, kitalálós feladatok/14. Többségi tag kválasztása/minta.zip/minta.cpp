#include "query.h"
#include <bits/stdc++.h>
using namespace std;
#define maxN 30001

int Init = false;
int Hany;
int kerd=0;
int bal=0, jobb=0;
bool Volt[maxN]={0};

int Size(){
   Init=true;
   Hany=15;
  return Hany;
}

int Member(int i, int j){
      if(!Init){
      cout<<"Protokoll hiba, Size() kell előbb"<<endl;
      return 1;
   }
     if (i < 1 || i > Hany || j < 1 || j > Hany) {
    cout<<"Hiba, érvénytelen paraméter!"<<endl;
    exit(1);
  }
  kerd++;
  Volt[i]=true; Volt[j]=true;
   return (i<=Hany/2 && j<=Hany/2) || (i>Hany/2 && j>Hany/2);
}

void Answer(int i){
  if (!Init) {
    cout<<"Hiba, protokoll hiba, Size() kell elõbb!"<<endl;
    exit(1);
  }
  int bal=0,jobb=0;
  for(int i=1;i<=Hany;i++){
   if(i<=Hany/2 && Volt[i]) bal++;
   if(i>Hany/2 && Volt[i]) jobb++;
  }
   bool ok=false;
   if(Volt[i]){
      ok=i>Hany/2 && jobb>Hany/2;
   }else{
      ok=false;
   }
   if(ok){
      cout<<"Helyes, pontszámod: "<<max(0,Hany-kerd)<<endl;
   }else{
      cout<<"Hibás többségi, pontszámod: 0"<<endl;
   }
}

